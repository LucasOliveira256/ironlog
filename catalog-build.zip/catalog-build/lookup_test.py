import json,sys,os
sys.path.insert(0,'.')
from lib import norm
ST=set(json.load(open(os.environ.get('OUT','exercises.json')))['normalize']['stopwords'])
def pn(s): return ' '.join(t for t in norm(s).split() if t not in ST)
d=json.load(open(os.environ.get('OUT','exercises.json')))
ix={}
for x in d['exercises']:
    for a in x['parser']: ix.setdefault(a,[]).append(x['id'])
    ix.setdefault(pn(x['pt']),[]).append(x['id']); ix.setdefault(pn(x['en']),[]).append(x['id'])
names="""Afundo parado
Prancha
Bicicleta ergométrica
Supino Barra Reta
Supino reto
Supino inclinado com halteres
Supino inclinado halter
Supino declinado
Supino na máquina
Crucifixo reto
Crucifixo inclinado
Crossover
Peck deck
Voador
Desenvolvimento com halteres
Desenvolvimento sentado
Desenvolvimento militar
Elevação lateral
Elevação frontal
Crucifixo inverso
Face pull
Remada alta
Encolhimento
Puxada frontal
Puxada aberta
Puxada supinada
Puxada triângulo
Barra fixa
Remada curvada
Remada baixa
Remada unilateral
Remada cavalinho
Remada máquina
Levantamento terra
Terra romeno
Stiff
Pull down
Pullover
Rosca direta
Rosca alternada
Rosca martelo
Rosca scott
Rosca concentrada
Rosca inversa
Rosca no cabo
Tríceps pulley
Tríceps corda
Tríceps testa
Tríceps francês
Tríceps coice
Mergulho no banco
Paralelas
Rosca punho
Agachamento livre
Agachamento no Smith
Agachamento sumô
Agachamento búlgaro
Agachamento hack
Agachamento goblet
Agachamento frontal
Leg press 45
Leg press horizontal
Cadeira extensora
Mesa flexora
Cadeira flexora
Cadeira abdutora
Cadeira adutora
Avanço
Passada
Afundo
Passada caminhando
Step up
Elevação pélvica
Hip thrust
Ponte de glúteos
Glúteo na polia
Coice
Abdução
Panturrilha em pé
Panturrilha sentada
Panturrilha no leg press
Abdominal supra
Abdominal infra
Abdominal remador
Abdominal oblíquo
Abdominal na polia
Abdominal canivete
Elevação de pernas
Elevação de pernas na barra
Prancha lateral
Roda abdominal
Russian twist
Lenhador
Pallof press
Lombar
Hiperextensão
Extensão lombar
Esteira
Caminhada na esteira
Corrida
Bike
Elíptico
Remo ergométrico
Escada
Pular corda
Polichinelo
Burpee
Mountain climber
Kettlebell swing
Turkish get up
Farmer walk
Alongamento de posterior
Alongamento de quadríceps
Alongamento de peitoral
Postura da criança
Gato e vaca
Mobilidade de quadril
Liberação miofascial
Supino com barra
Agachamento com barra
Remada com halteres
Flexão de braço
Flexão de braços
Afundo com halteres
Agachamento com halteres
Rosca bíceps
Tríceps na polia
Pulley costas
Triceps pulley barra reta""".split('\n')
miss=[];amb=[]
for n in names:
    k=pn(n)
    if k not in ix: miss.append(n)
    else:
        print(f"{n:34s} → {ix[k][0]}"+(f"  (+{len(ix[k])-1})" if len(ix[k])>1 else ''))
print('\nNÃO ENCONTRADOS:',miss)
