# -*- coding: utf-8 -*-
from lib import *
m = em
FAMS = []
A = FAMS.append

# ═════════ PEITO ═════════
A(Fam('bench','Bench Press','Supino','barbell dumbbell smith-machine',[CH],[FD,TRI],
  mods=[m(k='flat',en='Flat',pt='reto',dflt=True,syn=['supino','supino reto','supino plano','supino horizontal','supino chato','supino barra reta','supino com barra reta','supino reto barra','supino halteres reto','supino halter reto']),
        m(k='incline',en='Incline',pt='inclinado',s=[FD,TRI],syn=['supino inclinado','supino 45','supino inclinado 45']),
        m(k='decline',en='Decline',pt='declinado',syn=['supino declinado']),
        m(k='close',en='Close-Grip',pt='pegada fechada',pos='post',p=[TRI],s=[CH,FD],eq=['barbell','smith-machine','dumbbell'],syn=['supino fechado','supino pegada fechada']),
        m(k='wide',en='Wide-Grip',pt='pegada aberta',pos='post',eq=['barbell','smith-machine']),
        m(k='neutral',en='Neutral-Grip',pt='pegada neutra',pos='post',eq=['dumbbell']),
        m(k='incline-neutral',en='Incline Neutral-Grip',pt='inclinado pegada neutra',eq=['dumbbell'])],
  syn=['supino']))
# nomes do ChatGPT: "Supino Barra Reta"
A(Fam('chest-press','Chest Press','Supino','machine cable band',[CH],[FD,TRI],
  mods=[m(k='flat',en='',pt='',dflt=True,syn=['chest press','supino sentado','supino maquina','supino articulado','supino vertical']),
        m(k='incline',en='Incline',pt='inclinado'),m(k='decline',en='Decline',pt='declinado',eq=['machine','cable']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','band'],s=[FD,TRI,AB]),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','machine'])]))
A(Fam('floor-press','Floor Press','Supino no chão','barbell dumbbell kettlebell',[CH,TRI],[FD],
  mods=[m(k='',dflt=True),m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','kettlebell'])]))
A(Fam('guillotine','Guillotine Press','Supino guilhotina','barbell dumbbell',[CH],[FD,TRI]))
A(Fam('landmine-press','Landmine Press','Landmine press','landmine',[FD,CH],[TRI,SD],
  mods=[m(k='',dflt=True,pt=''),m(k='one-arm',en='One-Arm',pt='unilateral',u=True)],syn=['landmine press']))
A(Fam('svend','Svend Press','Svend press','plate',[CH],[FD,TRI]))
A(Fam('fly','Fly','Crucifixo','dumbbell cable machine band',[CH],[FD],force='push',mech='isolation',
  mods=[m(k='flat',en='Flat',pt='reto',dflt=True,eq=['dumbbell','cable'],syn=['crucifixo','crucifixo reto']),
        m(k='incline',en='Incline',pt='inclinado',eq=['dumbbell','cable'],syn=['crucifixo inclinado']),
        m(k='decline',en='Decline',pt='declinado',eq=['dumbbell','cable']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','band']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell']),
        m(k='pec-deck',full=True,en='Pec Deck Fly',pt='Voador (peck deck)',eq=['machine'],syn=['peck deck','pec deck','voador','voador peitoral','crucifixo maquina','fly maquina','borboleta'],dflt=True,nodef=False)],
  de='dumbbell',syn=[]))
A(Fam('crossover','Crossover','Crossover','cable',[CH],[FD],mech='isolation',
  mods=[m(k='high',en='High-to-Low',pt='polia alta',dflt=True,syn=['crossover','cross over','crucifixo na polia','crucifixo polia alta','crucifixo cruzado']),
        m(k='low',en='Low-to-High',pt='polia baixa',syn=['crossover baixo','crucifixo polia baixa']),
        m(k='mid',en='Mid',pt='polia média'),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True)]))
A(Fam('pushup','Push-Up','Flexão de braço','bodyweight',[CH],[FD,TRI,AB],
  mods=[m(k='',dflt=True,syn=['flexao','flexao de braco','flexao de bracos','flexoes','push up','pushup','flexao no solo']),
        m(k='wide',en='Wide',pt='pegada aberta'),m(k='close',en='Close-Grip',pt='pegada fechada',p=[TRI],s=[CH,FD]),
        m(k='diamond',en='Diamond',pt='diamante',p=[TRI],s=[CH,FD],syn=['flexao diamante','flexao fechada']),
        m(k='decline',en='Decline',pt='declinada (pés elevados)',syn=['flexao declinada','flexao com pes elevados']),
        m(k='incline',en='Incline',pt='inclinada (mãos elevadas)',syn=['flexao inclinada']),
        m(k='knee',en='Knee',pt='com joelhos apoiados',syn=['flexao com joelhos','flexao no joelho']),
        m(k='archer',en='Archer',pt='arqueiro'),m(k='clap',en='Clap',pt='com palmas',cat='plyometrics'),
        m(k='one-arm',en='One-Arm',pt='unilateral',uni=True),m(k='spiderman',en='Spiderman',pt='homem-aranha',s=[FD,TRI,AB,OB]),
        m(k='hand-release',en='Hand-Release',pt='com soltura das mãos'),m(k='pike',en='Pike',pt='pike',p=[FD],s=[TRI,CH,SD],syn=['flexao pike']),
        m(k='handstand',en='Handstand',pt='parada de mão',p=[FD],s=[TRI,SD,TR],syn=['flexao parada de mao']),
        m(k='ball',en='Stability Ball',pt='com pés na bola',equip='exercise-ball',s=[FD,TRI,AB]),
        m(k='deficit',en='Deficit',pt='com déficit'),m(k='weighted',en='Weighted',pt='com peso',syn=['flexao com peso'])]))
A(Fam('pushup-susp','Push-Up','Flexão de braço','suspension',[CH],[FD,TRI,AB]))
A(Fam('dip-chest','Dip','Mergulho nas paralelas','bodyweight machine',[CH,TRI],[FD],
  mods=[m(k='chest',en='Chest',pt='(foco peitoral)',dflt=True,syn=['paralelas','mergulho','mergulho nas paralelas','dips','dip']),
        m(k='triceps',en='Triceps',pt='(foco tríceps)',p=[TRI],s=[CH,FD],syn=['paralelas triceps','mergulho triceps']),
        m(k='weighted',en='Weighted',pt='com peso',eq=['bodyweight'],syn=['paralelas com peso']),
        m(k='assisted',en='Assisted',pt='assistido',eq=['machine'],syn=['paralelas assistida','mergulho assistido'])]))
A(Fam('pullover','Pullover','Pullover','dumbbell barbell cable machine ez-bar',[LA],[CH,TRI],mech='isolation',force='pull',
  mods=[m(k='',dflt=True,syn=['pull over','pullover']),m(k='straight-arm',en='Straight-Arm',pt='braços estendidos',eq=['cable','dumbbell']),
        m(k='bent-arm',en='Bent-Arm',pt='braços flexionados',eq=['barbell','dumbbell'])],de='dumbbell'))

# ═════════ OMBROS ═════════
A(Fam('shoulder-press','Shoulder Press','Desenvolvimento','dumbbell barbell machine smith-machine cable kettlebell band landmine',[FD,SD],[TRI,TR],
  mods=[m(k='seated',en='Seated',pt='sentado',dflt=True,eq=['dumbbell','barbell','machine','smith-machine','cable'],syn=['desenvolvimento','desenvolvimento sentado','desenvolvimento ombro','desenvolvimento de ombros']),
        m(k='standing',en='Standing',pt='em pé',eq=['dumbbell','barbell','smith-machine','cable','kettlebell','band','landmine'],syn=['desenvolvimento em pe','desenvolvimento militar','military press','overhead press']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','kettlebell','cable','landmine']),
        m(k='behind-neck',en='Behind-the-Neck',pt='atrás da nuca',eq=['barbell','smith-machine'],syn=['desenvolvimento atras da nuca','desenvolvimento nuca']),
        m(k='arnold',en='Arnold',pt='Arnold',eq=['dumbbell'],syn=['arnold press','desenvolvimento arnold']),
        m(k='alternating',en='Alternating',pt='alternado',eq=['dumbbell','kettlebell','cable']),
        m(k='neutral',en='Neutral-Grip',pt='pegada neutra',eq=['dumbbell'],syn=['desenvolvimento pegada neutra','desenvolvimento martelo'])],
  de='dumbbell'))
A(Fam('lateral-raise','Lateral Raise','Elevação lateral','dumbbell cable machine band',[SD],[TR],mech='isolation',
  mods=[m(k='',dflt=True,syn=['elevacao lateral','elevacao lateral de ombro','lateral raise','laterais','elevacao lateral em pe']),
        m(k='seated',en='Seated',pt='sentado',eq=['dumbbell','machine']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell']),
        m(k='leaning',en='Leaning',pt='inclinado de lado',eq=['cable','dumbbell']),
        m(k='lying',en='Lying',pt='deitado de lado',eq=['dumbbell']),
        m(k='behind-back',en='Behind-the-Back',pt='por trás do corpo',eq=['cable'])],de='dumbbell'))
A(Fam('front-raise','Front Raise','Elevação frontal','dumbbell barbell cable plate band ez-bar',[FD],[SD,CH],mech='isolation',
  mods=[m(k='',dflt=True,syn=['elevacao frontal','front raise']),m(k='alternating',en='Alternating',pt='alternada',eq=['dumbbell']),
        m(k='incline',en='Incline',pt='no banco inclinado',eq=['dumbbell']),m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell']),
        m(k='overhead',en='Overhead',pt='acima da cabeça',eq=['plate','barbell'])],de='dumbbell'))
A(Fam('rear-delt-fly','Rear Delt Fly','Crucifixo inverso','dumbbell cable machine band',[RD],[UB,TR],force='pull',mech='isolation',
  mods=[m(k='bent',en='Bent-Over',pt='curvado',eq=['dumbbell','cable','band'],dflt=True,syn=['crucifixo inverso','voador inverso','elevacao posterior','posterior de ombro','reverse fly','crucifixo invertido','peck deck inverso']),
        m(k='incline',en='Incline Bench',pt='no banco inclinado',eq=['dumbbell']),
        m(k='seated',en='Seated',pt='sentado',eq=['dumbbell']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell']),
        m(k='reverse-pec-deck',full=True,en='Reverse Pec Deck Fly',pt='Voador inverso (reverse peck deck)',eq=['machine'],syn=['voador inverso','peck deck inverso','reverse pec deck','crucifixo inverso maquina'],nodef=False,dflt=True)],de='dumbbell'))
A(Fam('face-pull','Face Pull','Face pull','cable band',[RD],[UB,TR,SD],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['face pull','puxada para o rosto','puxada facial']),m(k='kneeling',en='Kneeling',pt='ajoelhado'),m(k='one-arm',en='One-Arm',pt='unilateral',u=True)]))
A(Fam('upright-row','Upright Row','Remada alta','barbell dumbbell cable ez-bar smith-machine kettlebell band',[SD,TR],[BI,FD],force='pull',
  mods=[m(k='',dflt=True,syn=['remada alta','upright row','remada em pe']),m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','cable','smith-machine','kettlebell'])]))
A(Fam('shrug','Shrug','Encolhimento','barbell dumbbell smith-machine cable machine trap-bar kettlebell',[TR],[UB,FA],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['encolhimento','encolhimento de ombros','encolhimento trapezio','trapezio','shrug']),
        m(k='behind-back',en='Behind-the-Back',pt='por trás do corpo',eq=['barbell','smith-machine']),
        m(k='incline',en='Incline Bench',pt='no banco inclinado',eq=['dumbbell'])],de='dumbbell'))
A(Fam('external-rotation','External Rotation','Rotação externa de ombro','cable dumbbell band',[RD],[UB],mech='isolation',force='pull',
  mods=[m(k='',dflt=True,syn=['rotacao externa','rotacao externa de ombro','manguito rotador']),m(k='lying',en='Lying',pt='deitado',eq=['dumbbell'])],de='cable'))
A(Fam('internal-rotation','Internal Rotation','Rotação interna de ombro','cable band',[FD],[CH],mech='isolation',force='pull',syn=['rotacao interna']))
A(Fam('scaption','Scaption','Elevação em Y (scaption)','dumbbell cable',[SD,FD],[TR],mech='isolation',syn=['scaption','elevacao em y']))
A(Fam('cuban-press','Cuban Press','Cuban press','dumbbell barbell',[RD,SD],[FD,TR],syn=['cuban press']))
A(Fam('y-raise','Y Raise','Elevação em Y','dumbbell cable band',[SD,TR],[RD],mech='isolation'))

# ═════════ COSTAS ═════════
A(Fam('bent-row','Row','Remada curvada','barbell dumbbell smith-machine ez-bar kettlebell band landmine trap-bar',[LA,UB],[BI,RD,LB,FA],force='pull',
  mods=[m(k='bent',en='Bent-Over',pt='',dflt=True,keep=True,eq=['barbell','dumbbell','smith-machine','ez-bar','kettlebell','band'],syn=['remada curvada','remada curvada pronada','remada com barra','bent over row','remada livre']),
        m(k='underhand',en='Underhand',pt='supinada',eq=['barbell','smith-machine','ez-bar','dumbbell'],syn=['remada supinada','remada curvada supinada','yates row']),
        m(k='pendlay',en='Pendlay',pt='Pendlay',eq=['barbell'],syn=['pendlay row']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','kettlebell','landmine','cable'],syn=['remada unilateral','serrote','remada serrote','remada um braco']),
        m(k='chest-supported',en='Chest-Supported',pt='apoiada no banco',eq=['dumbbell','barbell'],syn=['remada apoiada','remada banco inclinado','remada peito apoiado']),
        m(k='incline',en='Incline Bench',pt='no banco inclinado',eq=['dumbbell']),
        m(k='two-arm-landmine',en='Two-Arm',pt='com as duas mãos',eq=['landmine']),
        m(k='meadows',en='Meadows',pt='Meadows',eq=['landmine','barbell'],syn=['meadows row'])],
  de='barbell',syn=['remada']))
A(Fam('seated-row','Seated Row','Remada sentada','cable machine band',[LA,UB],[BI,RD,FA],force='pull',
  mods=[m(k='close',en='Close-Grip',pt='pegada fechada (triângulo)',eq=['cable'],dflt=True,syn=['remada baixa','remada sentada','remada no cabo','remada triangulo','remada baixa triangulo','seated cable row','pulley baixo']),
        m(k='wide',en='Wide-Grip',pt='pegada aberta',eq=['cable','machine'],syn=['remada pegada aberta','remada baixa aberta','remada aberta']),
        m(k='machine-row',en='',pt='',eq=['machine'],dflt=True,syn=['remada maquina','remada na maquina','remada no aparelho','remada sentada maquina','remada articulada maquina','remada sentada na maquina']),
        m(k='neutral',en='Neutral-Grip',pt='pegada neutra',eq=['machine','cable'],syn=['remada pegada neutra']),
        m(k='underhand',en='Underhand',pt='pegada supinada',eq=['cable','machine'],syn=['remada supinada no cabo']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','machine','band'],syn=['remada unilateral no cabo']),
        m(k='high',en='High',pt='alta',eq=['machine','cable'],syn=['remada alta maquina']),
        m(k='iso',en='Iso-Lateral',pt='articulada unilateral',eq=['machine'],syn=['remada articulada']),
        m(k='rope',en='Rope',pt='com corda',eq=['cable'],syn=['remada com corda']),
        m(k='kneeling',en='Kneeling',pt='ajoelhado',eq=['cable']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','band'])],de='cable'))
A(Fam('chest-supported-row','Chest-Supported Row','Remada com apoio no peito','machine',[LA,UB],[BI,RD],force='pull',syn=['remada cavalinho apoiada','remada com peito apoiado']))
A(Fam('t-bar-row','T-Bar Row','Remada cavalinho','landmine machine barbell',[LA,UB],[BI,RD,LB],force='pull',
  mods=[m(k='',dflt=True,syn=['remada cavalinho','cavalinho','t bar','remada t','remada barra t']),m(k='chest-supported',en='Chest-Supported',pt='apoiada no peito',eq=['machine','landmine'])],de='landmine'))
A(Fam('inverted-row','Inverted Row','Remada invertida','bodyweight smith-machine suspension',[LA,UB],[BI,RD],force='pull',
  mods=[m(k='',dflt=True,syn=['remada invertida','australian pull up','remada australiana','remada na barra baixa','remada no trx']),m(k='feet-up',en='Feet-Elevated',pt='pés elevados')]))
A(Fam('seal-row','Seal Row','Remada seal','barbell dumbbell',[LA,UB],[BI,RD],force='pull',syn=['seal row']))
A(Fam('pulldown','Lat Pulldown','Puxada','cable machine',[LA],[BI,UB,RD],force='pull',
  mods=[m(k='wide',en='Wide-Grip',pt='frontal pegada aberta',dflt=True,syn=['puxada','puxada frontal','puxada alta','puxada aberta','pulldown','puxada na frente','pulley frente','lat pulldown','puxador frontal','puxada pela frente','pull down','pulley costas','pulley','puxada pulley','pulley frontal','puxada no pulley','pulley alto']),
        m(k='close',en='Close-Grip',pt='frontal pegada fechada',syn=['puxada fechada','puxada triangulo','puxada pegada fechada']),
        m(k='neutral',en='Neutral-Grip',pt='pegada neutra',syn=['puxada neutra','puxada pegada neutra','puxada v-bar','puxada triangulo']),
        m(k='reverse',en='Reverse-Grip',pt='supinada',syn=['puxada supinada','puxada invertida','puxada pegada supinada','puxada pegada invertida']),
        m(k='behind',en='Behind-the-Neck',pt='atrás da nuca',syn=['puxada atras','puxada nuca','puxada por tras','puxada atras da nuca']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,syn=['puxada unilateral','puxada um braco']),
        m(k='kneeling-single',en='Kneeling Single-Arm',pt='ajoelhado unilateral',eq=['cable']),
        m(k='iso',en='Iso-Lateral',pt='articulada',eq=['machine'])],de='cable'))
A(Fam('straight-arm-pulldown','Straight-Arm Pulldown','Pulldown com braços estendidos','cable band',[LA],[TRI,CH],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['pulldown braco reto','pulldown corda','puxada braco estendido','pullover na polia','pullover polia','pulldown na corda','pulldown corda reta','pulldown com corda']),m(k='rope',en='Rope',pt='com corda'),m(k='bar',en='Bar',pt='com barra reta')],de='cable'))
A(Fam('pullup','Pull-Up','Barra fixa','bodyweight machine band',[LA],[BI,UB,RD,FA],force='pull',
  mods=[m(k='',dflt=True,eq=['bodyweight'],syn=['barra fixa','pull up','pullup','barra fixa pronada','barra fixa pegada aberta','barras','dominada','dominadas','barra fixa dominada']),
        m(k='wide',en='Wide-Grip',pt='pegada aberta',eq=['bodyweight']),
        m(k='close',en='Close-Grip',pt='pegada fechada',eq=['bodyweight']),
        m(k='neutral',en='Neutral-Grip',pt='pegada neutra',eq=['bodyweight'],syn=['barra fixa neutra']),
        m(k='chin',en='Chin-Up',pt='supinada',eq=['bodyweight'],syn=['barra fixa supinada','chin up','chin-up','barra supinada']),
        m(k='weighted',en='Weighted',pt='com peso',eq=['bodyweight'],syn=['barra fixa com peso','barra fixa lastrada']),
        m(k='assisted',en='Assisted',pt='assistida',eq=['machine','band'],syn=['barra fixa assistida','graviton','barra assistida','pull up assistido']),
        m(k='commando',en='Commando',pt='comando',eq=['bodyweight']),
        m(k='archer',en='Archer',pt='arqueiro',eq=['bodyweight']),
        m(k='l-sit',en='L-Sit',pt='com elevação de pernas (L-sit)',eq=['bodyweight'],s=[BI,UB,AB]),
        m(k='one-arm',en='One-Arm',pt='unilateral',uni=True,eq=['bodyweight']),
        m(k='kipping',en='Kipping',pt='com kipping',eq=['bodyweight'],cat='plyometrics'),
        m(k='scapular',en='Scapular',pt='escapular',eq=['bodyweight'],p=[UB],s=[LA,TR],syn=['barra fixa escapular','scapular pull up'])]))
A(Fam('muscle-up','Muscle-Up','Muscle-up','bodyweight',[LA,TRI],[CH,BI,AB],force='pull',
  mods=[m(k='',dflt=True,syn=['muscle up','muscle-up']),m(k='ring',en='Ring',pt='nas argolas',syn=['muscle up argolas']),m(k='kipping',en='Kipping',pt='com kipping')]))
A(Fam('ring-row','Ring Row','Remada nas argolas','suspension',[LA,UB],[BI,RD],force='pull'))
A(Fam('pull-through','Pull-Through','Pull-through','cable band',[GL,HA],[LB],force='pull',syn=['pull through','puxada entre as pernas']))

# ═════════ BÍCEPS ═════════
A(Fam('curl','Curl','Rosca','barbell ez-bar dumbbell cable machine band kettlebell',[BI],[FA],force='pull',mech='isolation',
  mods=[m(k='standing',en='Standing',pt='direta',dflt=True,eq=['barbell','ez-bar','dumbbell','cable','band','kettlebell'],syn=['rosca','rosca direta','rosca de biceps','rosca biceps','biceps','rosca biceps em pe','biceps curl','curl']),
        m(k='alternating',en='Alternating',pt='alternada',eq=['dumbbell','cable'],syn=['rosca alternada','biceps alternado']),
        m(k='seated',en='Seated',pt='sentado',eq=['dumbbell'],syn=['rosca sentado']),
        m(k='machine',en='',pt='',eq=['machine'],syn=['rosca maquina','biceps maquina','biceps na maquina']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell'],syn=['rosca unilateral']),
        m(k='close',en='Close-Grip',pt='pegada fechada',pos='post',eq=['barbell','ez-bar'],syn=['rosca fechada','rosca pegada fechada']),
        m(k='wide',en='Wide-Grip',pt='pegada aberta',pos='post',eq=['barbell','ez-bar'],syn=['rosca aberta','rosca pegada aberta']),
        m(k='lying',en='Lying',pt='deitada',eq=['cable','barbell','dumbbell']),
        m(k='high-cable',full=True,en='High-Pulley Cable Curl',pt='Rosca na polia alta (double biceps)',eq=['cable'],syn=['rosca polia alta','rosca double biceps','rosca 21']),
        m(k='21s',en='21s',pt='21',eq=['barbell','ez-bar','dumbbell'],syn=['rosca 21','rosca vinte e um']),
        m(k='cross-body',en='Cross-Body',pt='cruzada',eq=['dumbbell','cable'],syn=['rosca cruzada']),
        m(k='overhead',en='Overhead',pt='acima da cabeça',eq=['cable'])],de='barbell'))
A(Fam('hammer-curl','Hammer Curl','Rosca martelo','dumbbell cable',[BI,FA],[],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca martelo','martelo','hammer curl','hammer','rosca neutra']),m(k='alternating',en='Alternating',pt='alternada',eq=['dumbbell']),
        m(k='rope',en='Rope',pt='com corda',eq=['cable'],syn=['rosca martelo corda','rosca martelo na polia']),
        m(k='incline',en='Incline',pt='no banco inclinado',eq=['dumbbell']),m(k='cross-body',en='Cross-Body',pt='cruzada',eq=['dumbbell']),
        m(k='seated',en='Seated',pt='sentado',eq=['dumbbell']),m(k='preacher',en='Preacher',pt='no banco Scott',eq=['dumbbell'])],de='dumbbell'))
A(Fam('preacher-curl','Preacher Curl','Rosca Scott','barbell ez-bar dumbbell cable machine',[BI],[FA],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca scott','scott','banco scott','preacher curl','rosca no banco scott','rosca scott barra w']),m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','cable','machine']),
        m(k='reverse',en='Reverse',pt='pegada pronada',eq=['barbell','ez-bar'],p=[FA,BI],s=[],syn=['rosca scott inversa'])],de='ez-bar'))
A(Fam('incline-curl','Incline Curl','Rosca inclinada','dumbbell cable',[BI],[FA],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca inclinada','rosca no banco inclinado','incline curl','rosca 45']),m(k='alternating',en='Alternating',pt='alternada',eq=['dumbbell']),
        m(k='prone',en='Prone',pt='de bruços',eq=['dumbbell'],syn=['rosca spider no banco'])],de='dumbbell'))
A(Fam('concentration-curl','Concentration Curl','Rosca concentrada','dumbbell cable',[BI],[FA],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca concentrada','concentrada','concentration curl']),m(k='standing',en='Standing',pt='em pé',eq=['dumbbell'])],de='dumbbell',uni=True))
A(Fam('spider-curl','Spider Curl','Rosca spider','dumbbell ez-bar barbell',[BI],[FA],force='pull',mech='isolation',syn=['rosca spider','spider curl'],de='dumbbell'))
A(Fam('drag-curl','Drag Curl','Rosca drag','barbell dumbbell',[BI],[FA],force='pull',mech='isolation',syn=['rosca drag','drag curl']))
A(Fam('bayesian-curl','Bayesian Curl','Rosca bayesiana','cable',[BI],[FA],force='pull',mech='isolation',syn=['rosca bayesiana','bayesian curl','rosca atras do corpo']))
A(Fam('zottman-curl','Zottman Curl','Rosca Zottman','dumbbell',[BI,FA],[],force='pull',mech='isolation',syn=['rosca zottman','zottman curl']))
A(Fam('reverse-curl','Reverse Curl','Rosca inversa','barbell ez-bar dumbbell cable',[FA,BI],[],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca inversa','rosca pronada','rosca invertida','reverse curl','rosca antebraco','rosca pegada pronada']),m(k='preacher',en='Preacher',pt='no banco Scott',eq=['ez-bar','barbell'])],de='ez-bar'))
A(Fam('wrist-curl','Wrist Curl','Rosca de punho','barbell dumbbell cable ez-bar',[FA],[],force='pull',mech='isolation',
  mods=[m(k='',dflt=True,syn=['rosca de punho','rosca punho','flexao de punho','antebraco','rosca de antebraco','wrist curl','rosca de punho palmas para cima']),
        m(k='reverse',en='Reverse',pt='inversa (extensora)',syn=['rosca punho invertida','extensao de punho','rosca de punho inversa','rosca punho pronada']),
        m(k='behind-back',en='Behind-the-Back',pt='por trás do corpo',eq=['barbell'])],de='barbell'))
A(Fam('finger-curl','Finger Curl','Rosca de dedos','barbell dumbbell',[FA],[],force='pull',mech='isolation'))

# ═════════ TRÍCEPS ═════════
A(Fam('pushdown','Triceps Pushdown','Tríceps','cable band machine',[TRI],[],mech='isolation',syn=['triceps'],
  mods=[m(k='rope',en='Rope',pt='corda',dflt=True,eq=['cable','band'],syn=['triceps corda','triceps pulley corda','triceps na corda','pushdown corda','triceps polia corda','pulley corda','triceps pulley']),
        m(k='bar',en='Straight-Bar',pt='barra reta',eq=['cable'],syn=['triceps barra reta','triceps pulley barra reta','triceps pulley barra','triceps pushdown','pushdown','triceps na barra','triceps barra','triceps polia','triceps polia barra','pulley triceps']),
        m(k='v-bar',en='V-Bar',pt='barra V',eq=['cable'],syn=['triceps barra v','triceps v-bar','triceps barra v pulley']),
        m(k='reverse',en='Reverse-Grip',pt='pegada supinada',eq=['cable','band'],syn=['triceps invertido','triceps pegada supinada','triceps polia supinado','triceps barra supinado']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','band'],syn=['triceps unilateral','triceps polia unilateral']),
        m(k='machine',en='',pt='',eq=['machine'],syn=['triceps maquina']),
        m(k='kneeling',en='Kneeling',pt='ajoelhado',eq=['cable'])],de='cable'))
A(Fam('overhead-ext','Overhead Triceps Extension','Tríceps francês','dumbbell cable ez-bar barbell kettlebell band',[TRI],[],mech='isolation',
  mods=[m(k='standing',en='Standing',pt='em pé',dflt=True,syn=['triceps frances','frances','triceps frances em pe','triceps testa em pe','extensao de triceps','triceps overhead','overhead triceps']),
        m(k='seated',en='Seated',pt='sentado',eq=['dumbbell','ez-bar','barbell','kettlebell'],syn=['triceps frances sentado']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','cable','kettlebell','band'],syn=['triceps frances unilateral']),
        m(k='rope',en='Rope',pt='com corda',eq=['cable'],syn=['triceps corda acima da cabeca','triceps frances corda','triceps frances na polia','triceps corda atras da cabeca']),
        m(k='lying',en='Lying',pt='deitado',eq=['cable'])],de='dumbbell'))
A(Fam('skullcrusher','Skullcrusher','Tríceps testa','ez-bar barbell dumbbell cable smith-machine band',[TRI],[],mech='isolation',
  mods=[m(k='',dflt=True,syn=['triceps testa','testa','skull crusher','skullcrusher','triceps testa barra w','triceps na testa','lying triceps extension']),
        m(k='incline',en='Incline',pt='inclinado',eq=['ez-bar','barbell','dumbbell']),
        m(k='decline',en='Decline',pt='declinado',eq=['ez-bar','barbell','dumbbell']),
        m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['dumbbell','cable'])],de='ez-bar'))
A(Fam('triceps-kickback','Triceps Kickback','Tríceps coice','dumbbell cable band',[TRI],[],mech='isolation',
  mods=[m(k='',dflt=True,syn=['triceps coice','coice triceps','kickback triceps','triceps kickback','coice de triceps']),m(k='one-arm',en='One-Arm',pt='unilateral',u=True,eq=['cable','dumbbell'])],de='dumbbell'))
A(Fam('jm-press','JM Press','JM press','barbell smith-machine dumbbell',[TRI],[CH,FD],syn=['jm press']))
A(Fam('tate-press','Tate Press','Tate press','dumbbell',[TRI],[],mech='isolation',syn=['tate press']))
A(Fam('bench-dip','Bench Dip','Mergulho no banco','bodyweight',[TRI],[CH,FD],mods=[m(k='',dflt=True,syn=['mergulho no banco','triceps banco','triceps no banco','bench dip','triceps mergulho','mergulho banco']),m(k='weighted',en='Weighted',pt='com peso',syn=['mergulho no banco com peso']),m(k='feet-up',en='Feet-Elevated',pt='pés elevados')]))
A(Fam('dip-machine','Triceps Dip','Tríceps na máquina (mergulho)','machine',[TRI],[CH,FD],syn=['triceps maquina mergulho','dip machine','mergulho na maquina']))
A(Fam('triceps-pushup','Close-Grip Push-Up','Flexão fechada','bodyweight',[TRI],[CH,FD],syn=['flexao triceps','flexao fechada triceps']))
A(Fam('skull-to-press','Lying Triceps Press','Tríceps supino (press)','ez-bar barbell',[TRI],[CH],mech='isolation',syn=['triceps press']))
