# -*- coding: utf-8 -*-
import json, re, sys, os, collections
sys.path.insert(0,'.')
import lib, fam_upper, fam_lower, fam_core, fam_extra, fam_extra2, match
from lib import *

VERSION='2026.11.03.2'
OUT=os.environ.get('OUT','exercises.json')
cur = expand(fam_upper.FAMS+fam_lower.FAMS+fam_core.FAMS+fam_extra.FAMS+fam_extra2.FAMS)

# ── cardio ──
CARDIO_META = {  # id → (equipamento, músculos primários)
 'treadmill-run':('cardio-machine',[QU,HA,GL,CA]),'treadmill-walk':('cardio-machine',[QU,HA,GL,CA]),
 'treadmill-incline-walk':('cardio-machine',[GL,HA,CA,QU]),'treadmill-intervals':('cardio-machine',[QU,HA,GL,CA]),
 'treadmill-sprint':('cardio-machine',[QU,HA,GL,CA]),'outdoor-run':('bodyweight',[QU,HA,GL,CA]),'trail-run':('bodyweight',[QU,HA,GL,CA]),
 'walk':('bodyweight',[QU,HA,GL,CA]),'hike':('bodyweight',[GL,QU,CA]),'stationary-bike':('cardio-machine',[QU,GL,HA,CA]),
 'recumbent-bike':('cardio-machine',[QU,GL,HA]),'spin':('cardio-machine',[QU,GL,HA,CA]),'air-bike':('cardio-machine',[QU,GL,HA,SD,LA]),
 'outdoor-cycling':('other',[QU,GL,HA,CA]),'elliptical':('cardio-machine',[QU,GL,HA,CA]),'rowing-machine':('cardio-machine',[LA,UB,QU,HA,BI]),
 'stair-climber':('cardio-machine',[GL,QU,CA]),'ski-erg':('cardio-machine',[LA,TRI,AB]),'arc-trainer':('cardio-machine',[QU,GL,HA]),
 'jump-rope':('other',[CA,QU,FA,SD]),'battle-ropes':('other',[SD,FD,AB,LA]),'jumping-jacks':('bodyweight',[QU,CA,SD,AB]),
 'high-knees':('bodyweight',[QU,AB,CA]),'butt-kicks':('bodyweight',[HA,CA,QU]),'swimming':('other',[LA,SD,CH,TRI,QU]),
 'shadow-boxing':('bodyweight',[SD,FD,OB,QU]),'heavy-bag':('other',[SD,FD,CH,OB,TRI]),'sprints':('bodyweight',[QU,HA,GL,CA]),
 'hiit':('other',[QU,GL,HA,AB,SD]),'dance-cardio':('other',[QU,GL,CA,AB]),'sled-cardio':('sled',[QU,GL,CA]),
 'cross-country':('cardio-machine',[QU,GL,LA,TRI]),'stepper':('cardio-machine',[GL,QU,CA]),'burpee-cardio':('bodyweight',[QU,CH,TRI,AB]),
}
for (id_,en,pt,syn) in fam_core.CARDIO:
    eq,prim=CARDIO_META[id_]
    cur.append(dict(en=en,pt=pt,equipment=eq,primary=prim,secondary=[],force='static',mechanic='compound',category='cardio',
        uni=False,parser=set([en,pt]+syn),default=True,fam='cardio-'+id_,src='curated'))
# ── alongamento / mobilidade ──
MOBILITY={'cat-cow','thoracic-rotation','hip-90-90','ankle-mobility','shoulder-circles','wall-slide','scapular-pushup','leg-swings',
          'torso-twist','inchworm','worlds-greatest-stretch','deep-squat-hold','band-pull-apart','dead-hang'}
MOBILITY |= {'thoracic-foam-roll','pec-foam-roll','tibialis-roll','hip-flexor-roll','lacrosse-glute','neck-rotation','lat-hang-stretch'}
ROLL={'thoracic-foam-roll','pec-foam-roll','tibialis-roll','hip-flexor-roll','lacrosse-glute'}
for (id_,en,pt,prim,syn) in fam_core.STRETCH+fam_extra.EXTRA_STRETCH:
    eq='foam-roll' if (id_.startswith('foam-roll') or id_ in ROLL) else ('band' if id_=='band-pull-apart' else ('bodyweight'))
    cat='mobility' if (id_ in MOBILITY or id_.startswith('foam-roll')) else 'stretching'
    cur.append(dict(en=en,pt=pt,equipment=eq,primary=prim,secondary=[],force='static',mechanic='isolation',category=cat,
        uni=False,parser=set([en,pt]+syn),default=True,fam='stretch-'+id_,src='curated'))

# ── índice por tokens (alvos de apelido) ──
idx=collections.defaultdict(list)
for x in cur: idx[match.tokens(x['en'])].append(x)

def add_alias(target_en, alias):
    k=match.tokens(target_en)
    if k not in idx: return False
    idx[k][0]['parser'].add(alias); return True

# ── base aberta ──
fe=json.load(open(os.environ.get('FEDB','fedb.json')))
keep_cat={'strength','powerlifting','olympic weightlifting','strongman','plyometrics'}
CATMAP={'strength':'strength','powerlifting':'powerlifting','olympic weightlifting':'olympic','strongman':'strongman','plyometrics':'plyometrics'}
EQMAP={'barbell':'barbell','dumbbell':'dumbbell','cable':'cable','machine':'machine','body only':'bodyweight','kettlebells':'kettlebell',
       'bands':'band','medicine ball':'medicine-ball','exercise ball':'exercise-ball','e-z curl bar':'ez-bar','other':'other',None:'bodyweight','foam roll':'foam-roll'}
MUS={'abdominals':AB,'abductors':ABD,'adductors':AD,'biceps':BI,'calves':CA,'chest':CH,'forearms':FA,'glutes':GL,'hamstrings':HA,'lats':LA,
     'lower back':LB,'middle back':UB,'neck':NE,'quadriceps':QU,'traps':TR,'triceps':TRI}
def delt(name, force, primary):
    n=name.lower()
    if re.search(r'rear|reverse fly|reverse flye|face pull|bent over.*raise|rear delt|lying.*raise',n): return RD
    if re.search(r'lateral|side raise|upright|laterals',n): return SD
    if re.search(r'press|front|clean|snatch|jerk|arnold|military|raise|push',n): return FD
    return SD
def fe_muscles(x):
    prim=[];sec=[]
    for m in x['primaryMuscles']:
        prim.append(delt(x['name'],x['force'],True) if m=='shoulders' else MUS[m])
    for m in x['secondaryMuscles']:
        if m=='shoulders':
            sec.append(FD if x['force']=='push' else (RD if x['force']=='pull' else SD))
        else: sec.append(MUS[m])
    prim=list(dict.fromkeys(prim)); sec=[s for s in dict.fromkeys(sec) if s not in prim]
    return prim,sec
def fe_equip(x):
    n=x['name'].lower()
    if 'smith' in n: return 'smith-machine'
    if 'landmine' in n or 'long bar' in n: return 'landmine'
    if re.search(r'\bsled\b|prowler|drag',n): return 'sled'
    if re.search(r'suspend|strap|trx|ring',n): return 'suspension'
    if 'trap bar' in n or 'rickshaw' in n or 'hex' in n: return 'trap-bar' if 'trap' in n else 'other'
    return EQMAP.get(x['equipment'],'other')

fmap={}
for line in open('fe_map.txt',encoding='utf-8'):
    line=line.rstrip('\n')
    if not line: continue
    a,b=line.split('::',1); fmap[a]=b
new_fe=[]; unresolved=[]; stats=collections.Counter()
strip=lambda n: re.sub(r"\s*-\s*(medium|wide|close|narrow)\s*grip.*$","",n,flags=re.I)
curkeys=set()
for x in cur:
    curkeys.add(norm(x['en']))
    for a in x['parser']: curkeys.add(norm(a))
for x in fe:
    if x['category'] not in keep_cat: continue
    nm=x['name']
    if norm(strip(nm)) in curkeys or norm(nm) in curkeys:
        stats['dup-exato']+=1; continue
    k=match.tokens(nm)
    if nm in fmap:
        v=fmap[nm]
        if v=='-': stats['descartado']+=1; continue
        if v.startswith('='):
            if add_alias(v[1:],nm): stats['alias']+=1
            else: unresolved.append((nm,v[1:])); 
            continue
        pt=v
    elif k in idx:
        idx[k][0]['parser'].add(nm); stats['alias-auto']+=1; continue
    else:
        unresolved.append((nm,'(sem mapa)')); continue
    prim,sec=fe_muscles(x)
    if not prim: continue
    _eq=fe_equip(x)
    if 'medicine ball' in pt.lower(): _eq='medicine-ball'
    elif 'anilha' in pt.lower(): _eq='plate'
    elif 'landmine' in pt.lower(): _eq='landmine'
    new_fe.append(dict(en=nm,pt=pt,equipment=_eq,primary=prim,secondary=sec,force=x['force'] or 'push',
        mechanic=x['mechanic'] or 'compound',category=CATMAP[x['category']],
        uni=bool(re.search(r'one[- ]arm|single[- ]arm|one[- ]leg|single[- ]leg|unilateral|alternating',nm,re.I)),
        parser=set([nm,pt]),default=False,fam=None,src='free-exercise-db'))
    stats['novo']+=1
print(dict(stats)); 
if unresolved:
    print('NÃO RESOLVIDOS:',len(unresolved))
    for u in unresolved: print('  ',u)
allx = cur + new_fe
_m={}; _out=[]; merged=0
for x in allx:
    k=norm(x['en'])
    if k in _m:
        _m[k]['parser'] |= x['parser']; merged+=1; continue
    _m[k]=x; _out.append(x)
allx=_out; print('duplicatas fundidas (mesmo nome EN):',merged)

# ── IDs únicos ──
seen={}
for x in allx:
    base=slug(x['en']); i=base
    if i in seen:
        i=f"{base}-{x['equipment']}"
        n=2
        while i in seen: i=f"{base}-{n}"; n+=1
        print('colisão de id:',base,'→',i)
    x['id']=i; seen[i]=x

# ── região ──
for x in allx: x['region']=region_of(x['primary'],x['category'])

# ── parser: normaliza (sem palavras de ligação) + resolve colisões ──
STOP_PT='com na no nas nos de da do das dos em e a o as os para pra pelo pela ao um uma'.split()
STOP_EN='with the to of on in and from an'.split()
STOP=set(STOP_PT+STOP_EN)
def pn(s): return ' '.join(t for t in norm(s).split() if t not in STOP)
for x in allx:
    s={pn(a) for a in x['parser']}
    s.add(pn(x['en'])); s.add(pn(x['pt']))
    s.discard(''); x['parser']=s
owners=collections.defaultdict(list)
for x in allx:
    for a in x['parser']: owners[a].append(x)
coll=0; dropped=0
for a,lst in owners.items():
    if len(lst)<2: continue
    coll+=1
    own_name=[x for x in lst if a in (pn(x['en']),pn(x['pt']))]
    if own_name: winner=own_name[0]
    else:
        d=[x for x in lst if x['default']]
        winner=d[0] if d else lst[0]
    for x in lst:
        if x is not winner: x['parser'].discard(a); dropped+=1
print(f'colisões de apelido: {coll} (removidos {dropped})')

# nomes PT duplicados entre exercícios diferentes
ptc=collections.Counter(pn(x['pt']) for x in allx)
dups=[p for p,c in ptc.items() if c>1]
print('PT duplicados:',len(dups)); 
for p in dups[:25]: print('   ',p,[x['id'] for x in allx if pn(x['pt'])==p])

# ── saída ──
CAT={'strength':('Musculação','Strength'),'powerlifting':('Powerlifting','Powerlifting'),'olympic':('Levantamento olímpico','Olympic lifting'),
 'strongman':('Strongman','Strongman'),'plyometrics':('Pliometria','Plyometrics'),'cardio':('Cardio','Cardio'),
 'stretching':('Alongamento','Stretching'),'mobility':('Mobilidade / liberação','Mobility / release')}
def j(o): return json.dumps(o,ensure_ascii=False,separators=(',',':'))
allx.sort(key=lambda x:(['upper','core','lower','full'].index(x['region']),x['category']=='stretching',x['id']))
lines=[]
for x in allx:
    d={'id':x['id'],'pt':x['pt'],'en':x['en'],'region':x['region'],'primary':x['primary'],'secondary':x['secondary'],
       'equipment':x['equipment'],'category':x['category'],'mechanic':x['mechanic'],'force':x['force']}
    if x['uni']: d['uni']=True
    if x['fam']: d['family']=x['fam']
    d['parser']=sorted(x['parser']-{pn(x['en']),pn(x['pt'])})
    lines.append('    '+j(d))
head={'schema':1,'version':VERSION,'count':len(allx),
 'normalize':{'steps':['minúsculas','remover acentos (NFD)','trocar tudo que não for a-z0-9 por espaço','remover palavras de ligação (stopwords)','juntar com espaço único'],'stopwords':sorted(STOP)},
 'about':'Catálogo de exercícios do IRONLOG. Para casar um texto: normalize-o (ver `normalize`) e procure em `parser` ou na versão normalizada de `pt`/`en` (estes dois NÃO ficam repetidos em `parser`). IDs são estáveis: nunca reutilize nem renomeie.',
 'sources':[{'name':'free-exercise-db','license':'Unlicense (domínio público)','url':'https://github.com/yuhonas/free-exercise-db'},{'name':'curadoria IRONLOG','note':'nomes PT-BR, apelidos de academia, taxonomia de músculos'}],
 'regions':{k:{'pt':v[0],'en':v[1]} for k,v in REGIONS.items()},
 'muscles':{k:{'pt':v[0],'en':v[1],'region':v[2]} for k,v in MUSCLES.items()},
 'equipment':{k:{'pt':v[1],'en':v[0]} for k,v in EQ.items()},
 'categories':{k:{'pt':v[0],'en':v[1]} for k,v in CAT.items()}}
out='{\n'
for k,v in head.items():
    out+=f'  "{k}": {j(v) if not isinstance(v,dict) or k=="regions" else ""}'
    if isinstance(v,dict) and k!='regions':
        out+='{\n'+',\n'.join(f'    "{kk}": {j(vv)}' for kk,vv in v.items())+'\n  }'
    out+=',\n'
out+='  "exercises": [\n'+',\n'.join(lines)+'\n  ]\n}\n'
open(OUT,'w',encoding='utf-8').write(out)
json.loads(out)  # valida
import os
print('exercícios:',len(allx),'| bytes:',os.path.getsize(OUT))
print(collections.Counter(x['region'] for x in allx)); print(collections.Counter(x['category'] for x in allx))
