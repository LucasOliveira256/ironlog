# -*- coding: utf-8 -*-
import re, unicodedata

def norm(s):
    s = unicodedata.normalize('NFD', s.lower())
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def slug(s): return norm(s.replace("'",'').replace('’','')).replace(' ', '-')

# ── músculos (20) ───────────────────────────────────────────
CH,FD,SD,RD,BI,TRI,FA,LA,UB,TR,LB,AB,OB,QU,HA,GL,CA,AD,ABD,NE = (
 'chest','front-delts','side-delts','rear-delts','biceps','triceps','forearms','lats','upper-back','traps',
 'lower-back','abs','obliques','quadriceps','hamstrings','glutes','calves','adductors','abductors','neck')
MUSCLES = {
 CH:('Peitoral','Chest','upper'), FD:('Deltoide anterior','Front delts','upper'), SD:('Deltoide lateral','Side delts','upper'),
 RD:('Deltoide posterior','Rear delts','upper'), BI:('Bíceps','Biceps','upper'), TRI:('Tríceps','Triceps','upper'),
 FA:('Antebraço','Forearms','upper'), LA:('Dorsal','Lats','upper'), UB:('Costas (meio)','Upper back','upper'),
 TR:('Trapézio','Traps','upper'), NE:('Pescoço','Neck','upper'),
 LB:('Lombar','Lower back','core'), AB:('Abdômen','Abs','core'), OB:('Oblíquos','Obliques','core'),
 QU:('Quadríceps','Quadriceps','lower'), HA:('Posterior de coxa','Hamstrings','lower'), GL:('Glúteos','Glutes','lower'),
 CA:('Panturrilha','Calves','lower'), AD:('Adutores','Adductors','lower'), ABD:('Abdutores','Abductors','lower'),
}
REGIONS = {'upper':('Superiores','Upper body'),'lower':('Inferiores','Lower body'),'core':('Core','Core'),'full':('Corpo inteiro','Full body')}

# ── equipamento: id → (EN, PT nome, frase PT no nome do exercício, [sinônimos PT p/ parser]) ──
EQ = {
 'barbell':('Barbell','Barra','com barra',['com barra','barra','barra livre']),
 'dumbbell':('Dumbbell','Halteres','com halteres',['com halteres','com halter','halteres','halter','dumbbell','com dumbell']),
 'cable':('Cable','Polia / cabo','na polia',['na polia','polia','no cabo','cabo','com cabo','crossover','pulley']),
 'machine':('Machine','Máquina','na máquina',['na maquina','maquina','no aparelho','aparelho','machine']),
 'smith-machine':('Smith Machine','Smith (barra guiada)','no Smith',['no smith','smith','barra guiada','smith machine','na barra guiada']),
 'kettlebell':('Kettlebell','Kettlebell','com kettlebell',['kettlebell','com kettlebell','kb']),
 'band':('Resistance Band','Elástico','com elástico',['com elastico','elastico','band','faixa elastica','mini band']),
 'ez-bar':('EZ-Bar','Barra W','com barra W',['com barra w','barra w','barra ez','barra z','ez']),
 'bodyweight':('Bodyweight','Peso do corpo','',[]),
 'landmine':('Landmine','Landmine','no landmine',['landmine','no landmine']),
 'suspension':('Suspension','TRX / suspensão','no TRX',['trx','no trx','suspensao','em suspensao']),
 'trap-bar':('Trap Bar','Barra hexagonal','com barra hexagonal',['barra hexagonal','trap bar','hex bar']),
 'plate':('Plate','Anilha','com anilha',['anilha','com anilha']),
 'medicine-ball':('Medicine Ball','Medicine ball','com medicine ball',['medicine ball','bola medicinal','wall ball']),
 'exercise-ball':('Stability Ball','Bola suíça','na bola suíça',['bola suica','bola','fitball','swiss ball','na bola']),
 'bosu':('Bosu','Bosu','no Bosu',['bosu','no bosu']),
 'sled':('Sled','Trenó','no trenó',['treno','sled','prowler']),
 'foam-roll':('Foam Roller','Rolo de espuma','com rolo',['rolo','foam roller','rolo de espuma']),
 'cardio-machine':('Cardio Machine','Aparelho de cardio','',[]),
 'other':('Other','Outro','',[]),
}

def em(**k): return k   # modificador

class Fam:
    """família de movimento → expande por equipamento × modificador"""
    def __init__(s, key, en, pt, eq, p, sec=(), mods=None, force='push', mech='compound', cat='strength',
                 syn=(), uni=False, de=None, noeq=False):
        s.__dict__.update(locals()); del s.__dict__['s']
        if isinstance(s.eq, str): s.eq = s.eq.split()
        s.mods = mods or [em(k='', en='', pt='', dflt=True)]
        s.de = de or s.eq[0]

EQNOUN={'barbell':['barra'],'dumbbell':['halter'],'cable':['polia','cabo'],'machine':['maquina','aparelho'],'smith-machine':['smith'],
 'kettlebell':['kettlebell'],'band':['elastico'],'ez-bar':['barra w'],'landmine':['landmine'],'suspension':['trx','suspens'],
 'trap-bar':['hexagonal'],'plate':['anilha'],'medicine-ball':['medicine ball'],'exercise-ball':['bola'],'sled':['treno'],'foam-roll':['rolo'],'bosu':['bosu']}
def _has_eq_pt(f,e,m):
    t=norm(f.pt+' '+(m.get('pt') or ''))
    return any(n in t for n in EQNOUN.get(e,[]))
def pt_phrase(f, e, m):
    if m.get('full'): return m['pt']
    E = '' if f.noeq else EQ[e][2]
    if E and _has_eq_pt(f,e,m): E=''
    if e == 'dumbbell' and E and (m.get('u') or f.uni): E = 'com halter'
    mp = m.get('pt') or ''
    pos = m.get('pos','pre')
    parts = [f.pt]
    if mp and pos == 'pre':
        if E and mp.startswith('com '):
            parts += [E, 'e ' + mp[4:]]; E=''
        else:
            parts.append(mp)
    if E: parts.append(E)
    s = ' '.join(parts)
    if mp and pos == 'post': s += ' - ' + mp
    return s

def en_phrase(f, e, m):
    if m.get('full'): return m['en']
    parts=[]
    if m.get('en') and m.get('pos','pre')=='pre' and (not m.get('dflt') or m.get('keep')): parts.append(m['en'])
    base_txt=(f.en+' '+(m.get('en') or '')).lower()
    if e!='bodyweight' and EQ[e][0]!='Other' and not f.__dict__.get('noeq') and EQ[e][0].lower() not in base_txt: parts.append(EQ[e][0])
    parts.append(f.en)
    s=' '.join(parts)
    if m.get('en') and m.get('pos')=='post': s += ' - ' + m['en']
    return s

def region_of(prim, cat):
    if cat in ('cardio',): return 'full'
    rs = {MUSCLES[x][2] for x in prim}
    if 'upper' in rs and 'lower' in rs: return 'full'
    if 'lower' in rs: return 'lower'
    if 'upper' in rs: return 'upper'
    return 'core'

DETECT={'dumbbell':r'\b(halter|halteres|dumbbell)\b','kettlebell':r'\bkettlebell\b','cable':r'\b(polia|cabo|pulley|crossover)\b',
 'machine':r'\b(maquina|aparelho)\b','smith-machine':r'\b(smith|barra guiada)\b','band':r'\b(elastico|faixa elastica|mini band)\b',
 'barbell':r'\b(barra livre|barbell)\b','ez-bar':r'\b(barra w|barra ez|barra z)\b','trap-bar':r'\b(hexagonal|trap bar)\b','suspension':r'\btrx\b',
 'landmine':r'\blandmine\b','plate':r'\banilha\b','exercise-ball':r'\bbola suica\b','bosu':r'\bbosu\b'}
def det(name):
    n=norm(name); return {k for k,p in DETECT.items() if re.search(p,n)}

def expand(fams):
    out=[]
    for f in fams:
        for e in f.eq:
            for m in f.mods:
                if m.get('eq') and e not in m['eq']: continue
                if m.get('noeq') and e in m['noeq']: continue
                en = en_phrase(f,e,m); pt = pt_phrase(f,e,m)
                prim = list(m.get('p') or f.p); sec = list(m.get('s') if m.get('s') is not None else f.sec)
                sec = [x for x in sec if x not in prim]
                mod_de = f.de if (not m.get('eq') or f.de in m['eq']) else m['eq'][0]
                is_def = (e==f.de) and bool(m.get('dflt'))
                core = f.pt + (' '+m['pt'] if (m.get('pt') and m.get('pos','pre')=='pre') else '')
                if m.get('full'): core = m['pt']
                A=set([en, pt])
                if e!='bodyweight' and not m.get('full'):
                    A.add(f"{EQ[e][0]} {m.get('en','')} {f.en}".replace('  ',' ').strip())
                for sy in EQ[e][3][:4]: A.add(f"{core} {sy}")
                if m.get('pt') and m.get('pos','pre')=='pre' and not m.get('full') and e!='bodyweight':
                    mp=m['pt']; variants={mp}
                    if mp.endswith('o'): variants.add(mp[:-1]+'a')
                    for sy in EQ[e][3][:5]:
                        sb=re.sub(r'^(com|na|no) ','',sy)
                        for v in variants: A.add(f"{f.pt} {sb} {v}")
                names = list(m.get('syn',[])) + (list(f.syn) if m.get('dflt') else [])
                if e==mod_de or any(det(sx) for sx in m.get('syn',[])):
                    if e==mod_de: A.add(core)
                    for sx in m.get('syn',[]):
                        d=det(sx)
                        if (not d and e==mod_de) or (d and e in d): A.add(sx)
                if is_def or (m.get('dflt') and any(det(sx) for sx in f.syn)):
                    for sx in f.syn:
                        d=det(sx)
                        if (not d and is_def) or (d and e in d and m.get('dflt')): A.add(sx)
                for sx in names:
                    if det(sx): continue
                    for sy in EQ[e][3][:4]:
                        if sy.split()[-1] not in sx: A.add(f"{sx} {sy}")
                out.append(dict(en=en.strip(),pt=pt.strip(),equipment=m.get('equip',e),primary=prim,secondary=sec,force=f.force,mechanic=f.mech,
                    category=m.get('cat',f.cat),uni=bool(m.get('u') or f.uni or m.get('uni')),parser=A,
                    default=is_def,fam=f.key,src='curated'))
    return out
