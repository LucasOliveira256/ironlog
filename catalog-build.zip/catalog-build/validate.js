const fs=require('fs');
const d=JSON.parse(fs.readFileSync('exercises.json','utf8'));
let errs=0; const bad=(m)=>{errs++; if(errs<=25) console.log('ERRO:',m);};
// normalização JS (a mesma que o app vai usar)
const STOP=new Set(d.normalize.stopwords);
const norm=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
const pn=s=>norm(s).split(' ').filter(t=>t&&!STOP.has(t)).join(' ');
const ids=new Set(), owner=new Map();
const M=new Set(Object.keys(d.muscles)), E=new Set(Object.keys(d.equipment)), C=new Set(Object.keys(d.categories)), R=new Set(Object.keys(d.regions));
for(const x of d.exercises){
  if(!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(x.id)) bad('id inválido '+x.id);
  if(ids.has(x.id)) bad('id duplicado '+x.id); ids.add(x.id);
  if(!x.pt||!x.en) bad('sem nome '+x.id);
  if(!R.has(x.region)) bad('região '+x.id);
  if(!E.has(x.equipment)) bad('equip '+x.id+' '+x.equipment);
  if(!C.has(x.category)) bad('categoria '+x.id);
  if(!x.primary.length) bad('sem primário '+x.id);
  for(const m of [...x.primary,...x.secondary]) if(!M.has(m)) bad('músculo '+m+' em '+x.id);
  if(x.primary.some(p=>x.secondary.includes(p))) bad('primário também secundário '+x.id);
  for(const a of x.parser){ if(a!==pn(a)) bad(`parser não normalizado em ${x.id}: "${a}"`); }
  for(const k of new Set([pn(x.pt),pn(x.en),...x.parser])){
    if(owner.has(k)&&owner.get(k)!==x.id) bad(`chave ambígua "${k}": ${owner.get(k)} e ${x.id}`); else owner.set(k,x.id);
  }
}
console.log('exercícios:',d.exercises.length,'| chaves de busca únicas:',owner.size,'| erros:',errs);
// campos obrigatórios por região
const rc={}; for(const x of d.exercises) rc[x.region]=(rc[x.region]||0)+1; console.log('por região',rc);
// quantidade por músculo primário (cobertura p/ mapa corporal)
const mc={}; for(const x of d.exercises) if(x.category==='strength') for(const p of x.primary) mc[p]=(mc[p]||0)+1;
console.log('musculação por músculo primário:',Object.entries(mc).sort((a,b)=>b[1]-a[1]).map(([k,v])=>k+':'+v).join(' '));
process.exit(errs?1:0);
