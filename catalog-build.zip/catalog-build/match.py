import re
from lib import norm
STOP={'the','a','an','with','on','to','of','from','over','and','for','in','at','position','style','version','medium','standard','grip','hands','hand','exercise'}
SYN={'db':'dumbbell','bb':'barbell','single':'one','alternate':'alternating','pulley':'cable','flye':'fly','flyes':'fly','flies':'fly','crunches':'crunch','lunges':'lunge','squats':'squat','curls':'curl','raises':'raise','presses':'press','rows':'row','dips':'dip','extensions':'extension','pulldowns':'pulldown','shrugs':'shrug','deadlifts':'deadlift','biceps':'bicep','triceps':'tricep','chins':'chin','kickbacks':'kickback','twists':'twist','swings':'swing','jumps':'jump','laterals':'lateral','situps':'situp','hops':'hop','pushups':'pushup','pullups':'pullup','rollouts':'rollout','raises':'raise','ups':'up','legs':'leg','arms':'arm','stance':'stance','full':'','bicycling':'bike'}
def tokens(name):
    n=name.lower()
    n=re.sub(r"push[\s\-]*ups?","pushup",n); n=re.sub(r"pull[\s\-]*ups?","pullup",n); n=re.sub(r"chin[\s\-]*ups?","chinup",n)
    n=re.sub(r"sit[\s\-]*ups?","situp",n); n=re.sub(r"step[\s\-]*ups?","stepup",n); n=re.sub(r"one[\s\-]*arm","onearm",n); n=re.sub(r"single[\s\-]*arm","onearm",n)
    n=re.sub(r"one[\s\-]*leg(ged)?","oneleg",n); n=re.sub(r"single[\s\-]*leg","oneleg",n); n=re.sub(r"two[\s\-]*arm","twoarm",n)
    n=re.sub(r"e[\s\-]*z[\s\-]*bar","ezbar",n); n=re.sub(r"v[\s\-]*bar","vbar",n); n=re.sub(r"t[\s\-]*bar","tbar",n)
    n=n.replace("smith machine","smith").replace("stiff-legged","stiff").replace("stiff legged","stiff").replace("stiff leg","stiff")
    n=n.replace("lat pulldown","pulldown").replace("military","overhead").replace("good mornings","good morning")
    n=norm(n)
    out=set()
    for t in n.split():
        t=SYN.get(t,t)
        if t in STOP or not t: continue
        if len(t)>3 and t.endswith('s') and not t.endswith('ss') and t not in ('triceps','biceps'): t=t[:-1]
        t=SYN.get(t,t)
        out.add(t)
    return frozenset(out)
