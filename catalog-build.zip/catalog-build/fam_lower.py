# -*- coding: utf-8 -*-
from lib import *
m = em
FAMS = []
A = FAMS.append

# ═════════ AGACHAMENTOS ═════════
A(Fam('squat','Squat','Agachamento','barbell smith-machine dumbbell kettlebell machine band landmine bodyweight',[QU,GL],[HA,AD,LB,AB],
  mods=[m(k='back',en='Back',pt='livre',dflt=True,eq=['barbell'],syn=['agachamento','agachamento livre','agachamento com barra','agachamento costas','back squat','squat','agachamento tradicional','agachamento na barra livre']),
        m(k='smith',en='',pt='',eq=['smith-machine'],syn=['agachamento smith','agachamento guiado','agachamento no smith','agachamento barra guiada']),
        m(k='goblet',en='Goblet',pt='goblet',eq=['dumbbell','kettlebell'],syn=['agachamento goblet','goblet squat','agachamento taça']),
        m(k='bw',full=True,en='Bodyweight Squat',pt='Agachamento livre (peso do corpo)',eq=['bodyweight'],syn=['agachamento livre sem peso','agachamento sem peso','air squat','agachamento corporal','agachamento com peso do corpo']),
        m(k='dumbbell',en='',pt='',eq=['dumbbell'],syn=['agachamento com halter','agachamento com halteres']),
        m(k='sumo',en='Sumo',pt='sumô',eq=['dumbbell','kettlebell','barbell','bodyweight','smith-machine'],syn=['agachamento sumo','agachamento sumô','sumo squat','agachamento plié','agachamento pliê']),
        m(k='machine',en='',pt='',eq=['machine'],syn=['agachamento maquina','agachamento no aparelho','agachamento guiado maquina']),
        m(k='band',en='',pt='',eq=['band'],syn=['agachamento elastico','agachamento com mini band']),
        m(k='landmine',en='',pt='',eq=['landmine'],syn=['agachamento landmine']),
        m(k='box',en='Box',pt='no caixote',eq=['barbell','bodyweight','dumbbell'],syn=['agachamento no caixote','agachamento no banco','box squat','agachamento banco']),
        m(k='pause',en='Pause',pt='com pausa',eq=['barbell'],syn=['agachamento com pausa','pause squat']),
        m(k='wide',en='Wide-Stance',pt='base aberta',eq=['barbell','smith-machine'],syn=['agachamento base aberta','agachamento afastado','agachamento pernas afastadas']),
        m(k='narrow',en='Narrow-Stance',pt='base fechada',eq=['barbell','smith-machine','bodyweight'],syn=['agachamento base fechada','agachamento pes juntos']),
        m(k='heels',en='Heels-Elevated',pt='com calcanhar elevado',eq=['barbell','dumbbell','bodyweight','smith-machine'],syn=['agachamento calcanhar elevado','agachamento com anilha embaixo do calcanhar']),
        m(k='jump',en='Jump',pt='com salto',eq=['bodyweight','barbell','dumbbell'],cat='plyometrics',syn=['agachamento com salto','jump squat','agachamento saltado','salto agachado']),
        m(k='1-5',en='1½-Rep',pt='1 e ¼',eq=['barbell','bodyweight'],syn=['agachamento 1 1/4']),
        m(k='overhead',en='Overhead',pt='overhead',eq=['barbell','dumbbell','kettlebell','bodyweight'],s=[FD,SD,TR,AB],syn=['overhead squat','agachamento overhead','agachamento com barra acima da cabeca']),
        m(k='zercher',en='Zercher',pt='Zercher',eq=['barbell'],syn=['agachamento zercher','zercher squat']),
        m(k='safety',en='Safety-Bar',pt='com barra de segurança',eq=['barbell'])],
  de='barbell'))
A(Fam('front-squat','Front Squat','Agachamento frontal','barbell smith-machine dumbbell kettlebell',[QU],[GL,AB,LB],
  mods=[m(k='',dflt=True,syn=['agachamento frontal','front squat','agachamento front','agachamento barra a frente']),m(k='pause',en='Pause',pt='com pausa',eq=['barbell']),m(k='double-kb',en='Double',pt='duplo',eq=['kettlebell'])],de='barbell'))
A(Fam('hack-squat','Hack Squat','Agachamento hack','machine barbell smith-machine',[QU],[GL,AD],
  mods=[m(k='',dflt=True,syn=['hack','hack squat','agachamento hack','agachamento no hack','hack machine']),m(k='narrow',en='Narrow-Stance',pt='base fechada',eq=['machine']),m(k='wide',en='Wide-Stance',pt='base aberta',eq=['machine']),
        m(k='reverse',en='Reverse',pt='invertido (de frente para o apoio)',eq=['machine'],p=[GL,QU])],de='machine'))
A(Fam('pendulum-squat','Pendulum Squat','Agachamento pêndulo','machine',[QU],[GL],syn=['agachamento pendulo','pendulum squat','pendulo']))
A(Fam('belt-squat','Belt Squat','Agachamento com cinto','machine',[QU,GL],[AD],syn=['belt squat','agachamento no cinto']))
A(Fam('v-squat','V-Squat','Agachamento V-squat','machine',[QU,GL],[AD],syn=['v squat']))
A(Fam('sissy-squat','Sissy Squat','Agachamento sissy','bodyweight machine',[QU],[],mech='isolation',
  mods=[m(k='',dflt=True,syn=['sissy squat','agachamento sissy']),m(k='weighted',en='Weighted',pt='com peso',eq=['bodyweight'])]))
A(Fam('pistol-squat','Pistol Squat','Agachamento pistol','bodyweight kettlebell smith-machine',[QU,GL],[HA,AB],uni=True,syn=['pistol squat','agachamento pistol','agachamento unilateral livre']))
A(Fam('split-squat','Split Squat','Afundo estático','dumbbell barbell smith-machine bodyweight kettlebell band suspension',[QU,GL],[HA,AD],uni=False,
  mods=[m(k='',dflt=True,syn=['afundo estatico','afundo parado','afundo','split squat','agachamento split','agachamento afundo','afundo na posicao estatica']),
        m(k='bulgarian',en='Bulgarian',pt='búlgaro',syn=['agachamento bulgaro','bulgaro','bulgarian split squat','afundo bulgaro','agachamento bulgaro com halteres','agachamento unilateral no banco','agachamento com pe de tras apoiado'],eq=['dumbbell','barbell','smith-machine','bodyweight','kettlebell']),
        m(k='front-elevated',en='Front-Foot-Elevated',pt='pé da frente elevado',eq=['dumbbell','barbell','bodyweight','smith-machine'],p=[GL,QU],syn=['afundo com pe da frente elevado','afundo deficit']),
        m(k='landmine',en='Landmine',pt='no landmine',eq=['landmine']),
        m(k='suspension',en='',pt='',eq=['suspension'],syn=['afundo no trx','agachamento bulgaro no trx'])],de='dumbbell'))
A(Fam('lunge','Lunge','Avanço','dumbbell barbell smith-machine bodyweight kettlebell band',[QU,GL],[HA,AD],
  mods=[m(k='forward',en='Forward',pt='à frente',dflt=True,syn=['avanco','avanco a frente','avanco frontal','passada','lunge','passada a frente','afundo dinamico','afundo avancando','avanço com halteres','afundo com passada']),
        m(k='reverse',en='Reverse',pt='para trás',syn=['avanco para tras','afundo reverso','passada para tras','avanco reverso','recuo','afundo para tras','reverse lunge']),
        m(k='walking',en='Walking',pt='caminhando',syn=['avanco caminhando','passada caminhando','walking lunge','passada andando','afundo caminhando','avanco andando','passada no corredor','avanco alternado caminhando']),
        m(k='lateral',en='Lateral',pt='lateral',eq=['dumbbell','barbell','bodyweight','kettlebell'],p=[QU,GL,AD],syn=['avanco lateral','afundo lateral','passada lateral','lateral lunge','agachamento lateral']),
        m(k='curtsy',en='Curtsy',pt='cruzado (curtsy)',eq=['dumbbell','bodyweight','kettlebell','barbell','smith-machine'],p=[GL,QU],syn=['curtsy lunge','avanco cruzado','afundo cruzado','reverencia','agachamento curtsy']),
        m(k='deficit',en='Deficit Reverse',pt='para trás em déficit',eq=['dumbbell','barbell','bodyweight'],p=[GL,QU],syn=['avanco deficit']),
        m(k='jump',en='Jump',pt='com salto',eq=['bodyweight'],cat='plyometrics',syn=['avanco com salto','jumping lunge','afundo com salto','passada com salto']),
        m(k='overhead',en='Overhead',pt='overhead',eq=['barbell','dumbbell','kettlebell','plate'],s=[HA,AD,FD,AB]),
        m(k='alternating',en='Alternating',pt='alternado',eq=['dumbbell','bodyweight','barbell','kettlebell'],syn=['avanco alternado','afundo alternado']),
        m(k='diagonal',en='Diagonal',pt='diagonal',eq=['bodyweight','dumbbell'],syn=['avanco diagonal']),
        m(k='elevated-reverse',en='Elevated Reverse',pt='para trás em step',eq=['dumbbell','bodyweight','barbell'],syn=['avanco para tras no step','afundo elevado para tras'])],de='dumbbell'))
A(Fam('step-up','Step-Up','Subida no banco (step-up)','dumbbell barbell bodyweight kettlebell',[QU,GL],[HA,CA],uni=True,
  mods=[m(k='',dflt=True,syn=['step up','step-up','subida no banco','subida no caixote','subida no step','subida em banco','subida na caixa','step up com halteres']),
        m(k='lateral',en='Lateral',pt='lateral',syn=['step up lateral','subida lateral']),
        m(k='knee-raise',en='Knee-Raise',pt='com elevação de joelho'),
        m(k='high',en='High-Box',pt='em caixote alto',eq=['dumbbell','bodyweight'],p=[GL,QU])],de='dumbbell'))
A(Fam('goblet-lunge','Cossack Squat','Agachamento cossaco','bodyweight dumbbell kettlebell',[QU,AD,GL],[HA],syn=['cossack squat','agachamento cossaco','cossaco']))
A(Fam('leg-press','Leg Press','Leg press','machine',[QU,GL],[HA,AD],
  mods=[m(k='45',en='45°',pt='45°',dflt=True,syn=['leg press','leg press 45','leg 45','legpress','leg press 45 graus','leg','leg press inclinado','leg press 45°']),
        m(k='horizontal',en='Horizontal',pt='horizontal',syn=['leg press horizontal','leg horizontal','leg press sentado']),
        m(k='single',en='Single-Leg',pt='unilateral',uni=True,syn=['leg press unilateral','leg press uma perna']),
        m(k='narrow',en='Narrow-Stance',pt='base fechada',syn=['leg press fechado','leg press pes juntos']),
        m(k='wide',en='Wide-Stance',pt='base aberta',p=[QU,GL,AD],syn=['leg press aberto','leg press pes afastados','leg press sumo']),
        m(k='high',en='High-Feet',pt='pés altos',p=[GL,HA],s=[QU,AD],syn=['leg press pes altos','leg press foco gluteo','leg press gluteo']),
        m(k='low',en='Low-Feet',pt='pés baixos',p=[QU],s=[GL],syn=['leg press pes baixos','leg press foco quadriceps']),
        m(k='vertical',en='Vertical',pt='vertical',syn=['leg press vertical'])],de='machine'))
A(Fam('leg-extension','Leg Extension','Cadeira extensora','machine band cable',[QU],[],mech='isolation',force='push',
  mods=[m(k='',dflt=True,syn=['cadeira extensora','extensora','extensao de pernas','leg extension','extensora de pernas','extensao de joelho','cadeira extensora bilateral']),m(k='single',en='Single-Leg',pt='unilateral',u=True,uni=True,syn=['extensora unilateral','extensora uma perna','cadeira extensora unilateral'])],de='machine'))
A(Fam('leg-curl','Leg Curl','Mesa flexora','machine band cable',[HA],[CA],mech='isolation',force='pull',
  mods=[m(k='lying',en='Lying',pt='deitada',dflt=True,syn=['mesa flexora','flexora deitada','mesa flexora deitada','leg curl','flexora','flexao de pernas','mesa flexora deitado','flexora deitado','curl de pernas']),
        m(k='standing',en='Standing',pt='em pé',eq=['machine','cable','band'],syn=['flexora em pe','flexora unilateral em pe','flexora de pe','flexora em pe unilateral']),
        m(k='single',en='Single-Leg',pt='unilateral',eq=['machine'],uni=True,syn=['flexora unilateral','mesa flexora unilateral'])],de='machine'))
A(Fam('leg-curl-seated','Seated Leg Curl','Cadeira flexora','machine band',[HA],[CA],mech='isolation',force='pull',
  syn=['cadeira flexora','flexora sentada','cadeira flexora sentado','flexora sentado','seated leg curl','flexora na cadeira','flexora sentada na maquina']))
A(Fam('leg-curl-ball','Stability Ball Leg Curl','Flexão de pernas na bola','exercise-ball',[HA],[CA],mech='isolation',force='pull',noeq=True,
  mods=[m(k='',dflt=True,syn=['flexao de pernas na bola','curl de pernas na bola','leg curl bola','flexora na bola','flexora com bola']),m(k='single',en='Single-Leg',pt='unilateral',uni=True)]))
A(Fam('nordic','Nordic Hamstring Curl','Flexão nórdica','bodyweight machine band',[HA],[GL,CA],force='pull',mech='isolation',syn=['nordic curl','flexao nordica','nordic hamstring','nordica'],de='bodyweight'))
A(Fam('slider-curl','Slider Leg Curl','Flexão de pernas com slider','bodyweight',[HA],[GL,CA],force='pull',mech='isolation',syn=['slider leg curl','flexora com slider','hamstring slide','flexao de perna com toalha']))
A(Fam('glute-ham','Glute-Ham Raise','Glute-ham raise (GHR)','machine bodyweight',[HA,GL],[LB],force='pull',syn=['ghr','glute ham raise','banco glute ham','glute-ham raise']))
# ═════════ TERRA / POSTERIOR ═════════
A(Fam('deadlift','Deadlift','Levantamento terra','barbell trap-bar dumbbell kettlebell smith-machine band',[GL,HA,LB],[QU,TR,FA,AB],force='pull',
  mods=[m(k='conv',en='Conventional',pt='convencional',dflt=True,eq=['barbell'],syn=['levantamento terra','terra','deadlift','terra convencional','levantamento terra convencional','levantamento de terra']),
        m(k='trap',en='',pt='',eq=['trap-bar'],syn=['terra com barra hexagonal','terra hex','terra trap bar','levantamento terra trap bar','levantamento terra hexagonal']),
        m(k='dumbbell',en='',pt='',eq=['dumbbell','kettlebell','smith-machine','band'],syn=['terra com halteres']),
        m(k='sumo',en='Sumo',pt='sumô',eq=['barbell','dumbbell','kettlebell','smith-machine'],syn=['terra sumo','levantamento terra sumo','sumo deadlift','levantamento terra sumô']),
        m(k='deficit',en='Deficit',pt='com déficit',eq=['barbell'],syn=['terra deficit']),
        m(k='snatch-grip',en='Snatch-Grip',pt='pegada de arranco',eq=['barbell'],p=[GL,HA,UB,LB]),
        m(k='single-leg',en='Single-Leg',pt='unilateral',eq=['dumbbell','kettlebell','barbell'],uni=True,syn=['terra unilateral','terra uma perna']),
        m(k='b-stance',en='B-Stance',pt='base escalonada',eq=['barbell','dumbbell','trap-bar'],syn=['terra b stance','terra assimetrico']),
        m(k='pause',en='Pause',pt='com pausa',eq=['barbell']),
        m(k='jefferson',en='Jefferson',pt='Jefferson',eq=['barbell'],syn=['terra jefferson','jefferson deadlift'])],de='barbell'))
A(Fam('rdl','Romanian Deadlift','Levantamento terra romeno','barbell dumbbell kettlebell smith-machine band trap-bar cable',[HA,GL],[LB,TR,FA],force='pull',
  mods=[m(k='',dflt=True,syn=['terra romeno','romeno','rdl','romanian deadlift','levantamento romeno','terra romeno com barra','stiff romeno']),
        m(k='single-leg',en='Single-Leg',pt='unilateral',eq=['dumbbell','kettlebell','barbell','smith-machine','cable'],uni=True,syn=['terra romeno unilateral','romeno unilateral','stiff unilateral','terra romeno uma perna']),
        m(k='deficit',en='Deficit',pt='com déficit',eq=['barbell','dumbbell']),
        m(k='staggered',en='Staggered-Stance',pt='base escalonada',eq=['dumbbell','barbell','kettlebell'],syn=['stiff escalonado','romeno b stance','romeno escalonado'])],de='barbell'))
A(Fam('stiff','Stiff-Leg Deadlift','Stiff','barbell dumbbell smith-machine kettlebell trap-bar',[HA,GL],[LB],force='pull',
  mods=[m(k='',dflt=True,syn=['stiff','levantamento terra stiff','stiff leg deadlift','terra stiff','stiff com barra','stiff com halteres','stiff leg'])],de='barbell'))
A(Fam('rack-pull','Rack Pull','Rack pull','barbell smith-machine trap-bar',[LB,TR,GL],[HA,UB,FA],force='pull',syn=['rack pull','terra no rack','terra parcial']))
A(Fam('good-morning','Good Morning','Bom dia (good morning)','barbell smith-machine band',[HA,LB],[GL],force='pull',
  mods=[m(k='',dflt=True,syn=['good morning','bom dia','bom dia com barra']),m(k='seated',en='Seated',pt='sentado',eq=['barbell']),m(k='stiff',en='Stiff-Leg',pt='pernas estendidas',eq=['barbell'])],de='barbell'))
A(Fam('hyperextension','Back Extension','Extensão lombar','bodyweight machine plate',[LB],[GL,HA],force='pull',mech='isolation',
  mods=[m(k='45',en='45° ',pt='no banco 45°',dflt=True,syn=['extensao lombar','hiperextensao','lombar','banco lombar','cadeira lombar','hyperextension','back extension','extensao de coluna','extensao lombar no banco','banco romano','extensao de tronco']),
        m(k='weighted',en='Weighted',pt='com peso',eq=['plate','bodyweight'],syn=['extensao lombar com peso','hiperextensao com anilha']),
        m(k='machine',en='',pt='',eq=['machine'],syn=['extensao lombar maquina','cadeira extensora lombar','lombar na maquina']),
        m(k='glute',en='Glute-Focused',pt='foco em glúteos',eq=['bodyweight','plate'],p=[GL,HA],s=[LB],syn=['hiperextensao gluteo','extensao de quadril 45']),
        m(k='single-leg',en='Single-Leg',pt='unilateral',eq=['bodyweight'],uni=True)],de='bodyweight'))
A(Fam('reverse-hyper','Reverse Hyperextension','Hiperextensão reversa','machine bodyweight',[GL,HA,LB],[],force='pull',syn=['reverse hyper','hiperextensao reversa','extensao reversa']))
A(Fam('superman','Superman','Superman','bodyweight',[LB],[GL,RD],force='pull',mech='isolation',syn=['superman','extensao de costas no solo','prone back extension','lombar no solo'],mods=[m(k='',dflt=True),m(k='dumbbell',en='Weighted',pt='com peso')]))
# ═════════ GLÚTEOS E QUADRIL ═════════
A(Fam('hip-thrust','Hip Thrust','Elevação pélvica','barbell smith-machine machine dumbbell band bodyweight kettlebell',[GL],[HA,QU,AD],
  mods=[m(k='',dflt=True,syn=['elevacao pelvica','hip thrust','ponte de gluteo','hipthrust','elevacao de quadril','elevacao pelvica com barra','hip thrust com barra','thrust']),
        m(k='single-leg',en='Single-Leg',pt='unilateral',eq=['bodyweight','dumbbell','barbell','smith-machine'],uni=True,syn=['elevacao pelvica unilateral','hip thrust unilateral','hip thrust uma perna']),
        m(k='b-stance',en='B-Stance',pt='base escalonada',eq=['barbell','smith-machine','dumbbell'],uni=False,syn=['hip thrust b stance']),
        m(k='feet-elevated',en='Feet-Elevated',pt='pés elevados',eq=['barbell','bodyweight','smith-machine']),
        m(k='machine',en='',pt='',eq=['machine'],syn=['elevacao pelvica maquina','hip thrust maquina','hip thrust no aparelho'])],de='barbell'))
A(Fam('glute-bridge','Glute Bridge','Ponte de glúteos','bodyweight barbell dumbbell band smith-machine exercise-ball',[GL],[HA],
  mods=[m(k='',dflt=True,syn=['ponte','ponte de gluteos','glute bridge','ponte glutea','ponte no solo','elevacao de pelve no solo','bridge']),
        m(k='single-leg',en='Single-Leg',pt='unilateral',uni=True,eq=['bodyweight','dumbbell','exercise-ball'],syn=['ponte unilateral','ponte uma perna']),
        m(k='feet-elevated',en='Feet-Elevated',pt='pés elevados',eq=['bodyweight'],p=[GL,HA]),
        m(k='march',en='Marching',pt='com marcha',eq=['bodyweight'])],de='bodyweight'))
A(Fam('glute-kickback','Glute Kickback','Coice de glúteo','cable machine band bodyweight smith-machine dumbbell',[GL],[HA],mech='isolation',uni=True,
  mods=[m(k='',dflt=True,syn=['coice','coice de gluteo','coice gluteo','glute kickback','gluteo na polia','kickback gluteo','extensao de quadril','extensao de quadril na polia','gluteo na polia baixa','gluteo 4 apoios','gluteo na maquina','coice na polia','gluteo coice']),
        m(k='quadruped',en='Quadruped',pt='em quatro apoios',eq=['bodyweight','band','dumbbell'],syn=['coice 4 apoios','coice em quatro apoios','donkey kick','coice de burro','chute de gluteo']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','machine','band']),
        m(k='smith',en='',pt='',eq=['smith-machine'],syn=['coice no smith','gluteo no smith'])],de='cable'))
A(Fam('fire-hydrant','Fire Hydrant','Fire hydrant (abdução em quatro apoios)','bodyweight band cable',[GL,ABD],[],mech='isolation',uni=True,syn=['fire hydrant','hidrante','abducao em quatro apoios']))
A(Fam('hip-abduction','Hip Abduction','Abdução de quadril','machine cable band bodyweight',[ABD,GL],[],mech='isolation',
  mods=[m(k='',dflt=True,syn=['abducao','abducao de quadril','cadeira abdutora','abdutora','abducao de coxa','abductor','hip abduction','abducao de pernas','abducao de quadril na maquina']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','band','machine'],syn=['abducao em pe','abducao na polia']),
        m(k='lying',en='Side-Lying',pt='deitada de lado',eq=['bodyweight','band'],syn=['abducao deitada','elevacao lateral de perna','levantamento lateral de perna','side leg raise','abducao no solo']),
        m(k='lateral-walk',full=True,en='Banded Lateral Walk',pt='Caminhada lateral com elástico',eq=['band'],syn=['caminhada lateral com elastico','lateral band walk','monster walk','passada lateral elastico','caminhada de monstro']),
        m(k='clamshell',full=True,en='Clamshell',pt='Concha (clamshell)',eq=['bodyweight'],syn=['clamshell','concha','abducao concha'])],de='machine'))
A(Fam('hip-adduction','Hip Adduction','Adução de quadril','machine cable band bodyweight',[AD],[],mech='isolation',
  mods=[m(k='',dflt=True,syn=['aducao','aducao de quadril','cadeira adutora','adutora','aducao de coxa','adductor','hip adduction','aducao de pernas','cadeira aducao']),
        m(k='standing',en='Standing',pt='em pé',eq=['cable','band'],syn=['aducao na polia','aducao em pe']),
        m(k='side-lying',en='Side-Lying',pt='deitada de lado',eq=['bodyweight'],syn=['aducao deitada']),
        m(k='copenhagen',full=True,en='Copenhagen Plank',pt='Prancha Copenhagen',eq=['bodyweight'],cat='strength',p=[AD],s=[OB,AB],force='static',syn=['copenhagen','copenhagen plank','prancha copenhagen']),
        m(k='ball-squeeze',full=True,en='Ball Squeeze Hip Adduction',pt='Adução com bola entre os joelhos',eq=['bodyweight'],syn=['aducao com bola','compressao de bola entre joelhos'])],de='machine'))
A(Fam('frog-pump','Frog Pump','Frog pump','bodyweight dumbbell band',[GL],[AD],mech='isolation',syn=['frog pump','ponte de sapo']))
A(Fam('hip-flexion','Hip Flexion','Flexão de quadril','cable band',[QU],[AB],mech='isolation',syn=['flexao de quadril','elevacao de joelho na polia']))
# ═════════ PANTURRILHA ═════════
A(Fam('calf-raise','Calf Raise','Elevação de panturrilha','machine smith-machine barbell dumbbell bodyweight band',[CA],[],mech='isolation',
  mods=[m(k='standing',en='Standing',pt='em pé',dflt=True,eq=['machine','smith-machine','barbell','dumbbell','bodyweight','band'],syn=['panturrilha','panturrilha em pe','gemeos','gemeos em pe','calf raise','elevacao de panturrilha','elevacao de calcanhar','panturrilha no smith','panturrilha na maquina em pe','panturrilha livre','elevacao de gemeos','panturrilha em pé unilateral']),
        m(k='seated',en='Seated',pt='sentada',eq=['machine','barbell','dumbbell'],syn=['panturrilha sentada','panturrilha sentado','soleo','seated calf raise','gemeos sentado','panturrilha na maquina sentado']),
        m(k='single-leg',en='Single-Leg',pt='unilateral',eq=['bodyweight','dumbbell','machine','smith-machine'],uni=True,syn=['panturrilha unilateral','panturrilha uma perna','panturrilha unilateral em pe']),
        m(k='donkey',en='Donkey',pt='burrinho (donkey)',eq=['machine','bodyweight'],syn=['panturrilha burrinho','donkey calf raise','panturrilha no burro','burrinho']),
        m(k='stair',en='Stair',pt='no degrau',eq=['bodyweight','dumbbell'],syn=['panturrilha no degrau','panturrilha no step']),
        m(k='jump',en='Jump',pt='com salto',eq=['bodyweight'],cat='plyometrics',syn=['pulos de panturrilha','panturrilha com salto']),
        m(k='leg-press',en='Leg Press',pt='no leg press',eq=['machine'],syn=['panturrilha no leg press','panturrilha leg press','gemeos no leg press']),
        m(k='hack',en='Hack',pt='no hack',eq=['machine'],syn=['panturrilha no hack'])],de='machine'))
A(Fam('tibialis','Tibialis Raise','Elevação de tibial','bodyweight machine band',[CA],[],mech='isolation',syn=['tibial anterior','elevacao de tibial','tibialis raise','dorsiflexao']))
A(Fam('ankle-pump','Ankle Dorsiflexion','Dorsiflexão','band cable',[CA],[],mech='isolation'))
# ═════════ OLÍMPICOS / POTÊNCIA ═════════
OLY=dict(cat='olympic')
A(Fam('power-clean','Power Clean','Power clean','barbell dumbbell kettlebell',[GL,HA,TR],[QU,LB,FD],force='pull',cat='olympic',syn=['power clean','arranco de forca','levantamento de forca'],
  mods=[m(k='',dflt=True),m(k='hang',en='Hang',pt='suspenso',syn=['hang power clean']),m(k='blocks',en='From Blocks',pt='dos blocos',eq=['barbell'])]))
A(Fam('clean','Clean','Clean (arremesso)','barbell dumbbell kettlebell',[GL,HA,QU,TR],[LB,FD],force='pull',cat='olympic',
  mods=[m(k='',dflt=True,syn=['clean','arremesso']),m(k='hang',en='Hang',pt='suspenso',syn=['hang clean']),m(k='squat',en='Squat',pt='com agachamento',syn=['squat clean']),m(k='split',en='Split',pt='com afundo',eq=['barbell'])]))
A(Fam('snatch','Snatch','Arranco (snatch)','barbell dumbbell kettlebell',[GL,HA,QU,TR,SD],[LB,TRI],force='pull',cat='olympic',
  mods=[m(k='',dflt=True,syn=['snatch','arranco']),m(k='power',en='Power',pt='de força',syn=['power snatch']),m(k='hang',en='Hang',pt='suspenso',syn=['hang snatch']),m(k='one-arm',en='One-Arm',pt='unilateral',eq=['dumbbell','kettlebell'],u=True,uni=True,syn=['snatch unilateral','arranco unilateral'])]))
A(Fam('clean-jerk','Clean and Jerk','Arremesso e arranco (clean and jerk)','barbell kettlebell dumbbell',[GL,QU,HA,FD,TRI],[TR,AB],force='pull',cat='olympic',syn=['clean and jerk','clean & jerk','arremesso e desenvolvimento']))
A(Fam('clean-press','Clean and Press','Clean and press','barbell dumbbell kettlebell',[GL,HA,FD,TRI],[QU,TR],force='pull',cat='olympic',syn=['clean and press','clean & press']))
A(Fam('jerk','Jerk','Jerk','barbell kettlebell dumbbell',[FD,TRI,QU],[GL,TR],cat='olympic',
  mods=[m(k='push',en='Push',pt='',dflt=True,syn=['push jerk','jerk']),m(k='split',en='Split',pt='com afundo (split jerk)',syn=['split jerk']),m(k='power',en='Power',pt='de força (power jerk)',eq=['barbell'],syn=['power jerk'])]))
A(Fam('thruster','Thruster','Thruster','barbell dumbbell kettlebell',[QU,GL,FD],[TRI,AB],cat='strength',syn=['thruster','agachamento com desenvolvimento','agachamento + desenvolvimento']))
A(Fam('swing','Swing','Swing','kettlebell dumbbell',[GL,HA],[LB,FD,AB],force='pull',
  mods=[m(k='russian',en='Russian',pt='russo',dflt=True,syn=['swing','kettlebell swing','swing com kettlebell','balanço com kettlebell','swing russo','russian swing']),
        m(k='american',en='American',pt='americano',eq=['kettlebell'],syn=['swing americano','american swing'],s=[FD,TRI,LB]),
        m(k='one-arm',en='One-Arm',pt='unilateral',eq=['kettlebell','dumbbell'],u=True,uni=True,syn=['swing unilateral','swing uma mao'])],de='kettlebell'))
A(Fam('turkish-getup','Turkish Get-Up','Levantamento turco','kettlebell dumbbell bodyweight',[AB,GL,FD],[OB,QU,TRI],syn=['turkish get up','levantamento turco','get up','tgu']))
A(Fam('windmill','Windmill','Windmill','kettlebell dumbbell barbell',[OB,AB],[GL,HA,SD],syn=['windmill','moinho']))
A(Fam('halo','Halo','Halo','kettlebell dumbbell plate',[SD,FD],[TR,AB,TRI],mech='isolation',syn=['halo','halo kettlebell']))
A(Fam('clean-pull','Clean Pull','Clean pull','barbell',[GL,HA,TR],[LB],force='pull',cat='olympic',syn=['clean pull','puxada de clean']))
A(Fam('snatch-pull','Snatch Pull','Snatch pull','barbell',[GL,HA,TR],[LB,UB],force='pull',cat='olympic',syn=['snatch pull','puxada de snatch']))
A(Fam('high-pull','High Pull','High pull','barbell kettlebell dumbbell',[TR,SD,GL],[BI,HA],force='pull',cat='olympic',syn=['high pull','puxada alta olimpica']))
A(Fam('push-press','Push Press','Push press','barbell dumbbell kettlebell',[FD,TRI,QU],[SD,GL],mods=[m(k='',dflt=True),m(k='behind',en='Behind-the-Neck',pt='atrás da nuca',eq=['barbell'])],syn=[]))
A(Fam('box-jump','Box Jump','Salto na caixa (box jump)','bodyweight',[QU,GL],[CA,HA],cat='plyometrics',
  mods=[m(k='',dflt=True,syn=['box jump','salto no caixote','salto na caixa','salto no step','pulo na caixa','salto em caixote','salto no banco']),m(k='lateral',en='Lateral',pt='lateral'),m(k='single',en='Single-Leg',pt='unilateral',uni=True),m(k='depth',en='Depth',pt='com queda',syn=['depth jump','salto em profundidade'])]))
A(Fam('broad-jump','Broad Jump','Salto horizontal','bodyweight',[QU,GL,HA],[CA],cat='plyometrics',syn=['broad jump','salto em distancia','salto horizontal','standing long jump','salto em distancia parado']))
A(Fam('skater-jump','Skater Jump','Salto patinador','bodyweight',[GL,QU,AD],[ABD,CA],cat='plyometrics',syn=['skater jump','patinador','salto lateral patinador','skater','pulo de patinador']))
A(Fam('tuck-jump','Tuck Jump','Salto com joelhos ao peito','bodyweight',[QU,GL],[CA,AB],cat='plyometrics',syn=['tuck jump','salto tuck','salto grupado']))
A(Fam('burpee','Burpee','Burpee','bodyweight',[CH,QU,TRI],[FD,GL,AB],cat='cardio',mods=[m(k='',dflt=True,syn=['burpee','burpees']),m(k='pushup',en='Push-Up',pt='com flexão',syn=['burpee com flexao']),m(k='box',en='Box Jump',pt='com salto na caixa'),m(k='pullup',en='Pull-Up',pt='com barra fixa'),m(k='dumbbell',en='Dumbbell',pt='com halteres',eq=['dumbbell'])]))
A(Fam('medball-slam','Slam Ball','Slam ball (arremesso no chão)','medicine-ball',[AB,LA,FD],[TRI,GL],cat='plyometrics',noeq=True,syn=['slam ball','wall ball slam','arremesso no chao','slam','arremesso de bola no chao']))
A(Fam('wall-ball','Wall Ball','Wall ball','medicine-ball',[QU,GL,FD],[TRI,AB],cat='plyometrics',noeq=True,syn=['wall ball','arremesso na parede','arremesso de bola na parede']))
A(Fam('medball-throw','Medicine Ball Throw','Arremesso de medicine ball','medicine-ball',[CH,FD,TRI],[AB,OB],cat='plyometrics',
  mods=[m(k='chest',en='Chest Pass',pt='de peito',dflt=True,syn=['arremesso de peito','chest pass','passe de peito','arremesso medicine ball']),m(k='rotational',en='Rotational',pt='rotacional',p=[OB],s=[AB,GL],syn=['arremesso rotacional','rotational throw']),m(k='overhead',en='Overhead',pt='acima da cabeça',p=[AB,LA],s=[FD]),m(k='scoop',en='Scoop',pt='por baixo',p=[GL,HA],s=[LB,AB])],noeq=True))
# ═════════ CARREGADAS ═════════
A(Fam('farmer-walk','Farmer\'s Walk','Caminhada do fazendeiro','dumbbell kettlebell trap-bar barbell',[FA,TR],[AB,OB,GL],force='static',cat='strongman',syn=['farmer walk','caminhada do fazendeiro','farmers walk','farmer carry','carregada','carga do fazendeiro','farmer'],de='dumbbell'))
A(Fam('suitcase-carry','Suitcase Carry','Carregada unilateral (suitcase)','dumbbell kettlebell',[OB,FA],[AB,TR],force='static',uni=True,syn=['suitcase carry','carregada unilateral','caminhada com peso de um lado'],de='dumbbell'))
A(Fam('overhead-carry','Overhead Carry','Carregada acima da cabeça','dumbbell kettlebell barbell plate',[FD,TR,AB],[SD,OB],force='static',syn=['overhead carry','carregada overhead','waiter walk']))
A(Fam('rack-carry','Front Rack Carry','Carregada no rack frontal','kettlebell dumbbell barbell',[AB,QU,UB],[FA],force='static',syn=['front rack carry','carregada rack']))
A(Fam('sled-push','Sled Push','Empurrar trenó','sled',[QU,GL],[CA,HA,AB],cat='strongman',noeq=True,syn=['sled push','empurrar treno','empurrar o treno','trenó empurrar','prowler push','prowler']))
A(Fam('sled-pull','Sled Pull','Puxar trenó','sled',[QU,GL,HA],[CA,UB],cat='strongman',noeq=True,syn=['sled pull','puxar treno','arrastar treno','sled drag','treno arrastar']))
A(Fam('tire-flip','Tire Flip','Virada de pneu','other',[GL,HA,QU,LB],[TR,BI],cat='strongman',syn=['tire flip','virar pneu','virada de pneu']))
A(Fam('sledgehammer','Sledgehammer Strike','Marretada no pneu','other',[OB,AB,FD],[LA,TRI,GL],cat='strongman',syn=['marreta','sledgehammer','marreta no pneu']))
A(Fam('yoke-walk','Yoke Walk','Caminhada com yoke','other',[QU,GL,TR,AB],[LB],force='static',cat='strongman',syn=['yoke walk','yoke']))
A(Fam('atlas-stone','Atlas Stone Load','Levantamento de pedra atlas','other',[GL,HA,LB,BI],[QU,AB],force='pull',cat='strongman',syn=['atlas stone','pedra atlas']))
A(Fam('log-press','Log Press','Desenvolvimento com log','other',[FD,TRI],[SD,QU],cat='strongman',syn=['log press','log lift']))
